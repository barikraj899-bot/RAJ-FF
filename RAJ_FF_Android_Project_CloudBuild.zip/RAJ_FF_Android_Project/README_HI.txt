RAJ FF COLOUR PANEL V1 - Android project with cloud APK build

आपके 2GB RAM वाले फोन पर Android Studio चलाने की जरूरत नहीं है। GitHub Actions में APK cloud runner पर build करने के लिए workflow जोड़ा गया है।

फोन से सामान्य प्रक्रिया:
1. ZIP को डाउनलोड करके extract करें।
2. GitHub पर नया repository बनाएं।
3. Extract किए गए project की सभी फाइलें (छिपा हुआ .github फ़ोल्डर सहित) repository में upload करें।
4. GitHub repository में Actions टैब खोलें।
5. "Build RAJ FF APK" workflow चुनकर "Run workflow" दबाएं।
6. Build सफल होने पर workflow run के Artifacts भाग से RAJ-FF-debug-apk डाउनलोड करें।
7. ZIP extract करके APK इंस्टॉल करें।

जरूरी: GitHub account और इंटरनेट चाहिए। Build failure होने पर Actions log में error देखना होगा।
यह ऐप केवल standalone UI demo है; Free Fire गेम को modify/control नहीं करता।

Project uses Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, Android SDK 35.
