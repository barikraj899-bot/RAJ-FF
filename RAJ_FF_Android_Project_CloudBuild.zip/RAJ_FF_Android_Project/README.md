# RAJ FF Colour Panel

A simple Android WebView wrapper for the supplied RAJ FF Colour Panel HTML demo.

## Build APK online with GitHub Actions
1. Upload the **contents** of this folder to the root of a GitHub repository (not the ZIP file itself).
2. Open the repository's **Actions** tab.
3. Select **Build RAJ FF APK** and press **Run workflow** (or push to `main`).
4. When the run completes, open it and download the `RAJ-FF-debug-apk` artifact.

This is a standalone UI demo. Its switches and colours affect only the panel; it does not modify or connect to Free Fire.
